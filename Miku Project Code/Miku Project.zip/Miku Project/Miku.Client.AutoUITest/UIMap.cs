﻿namespace Miku.Client.AutoUITest
{
    public partial class UIMap
    {
    }
}